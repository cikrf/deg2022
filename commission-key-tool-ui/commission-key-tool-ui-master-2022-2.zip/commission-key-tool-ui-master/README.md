## How to dev

1. `yarn`
2. `yarn start`

## How to build

Each platform can only be built on corresponding OS (virtualbox is fine)
(because native dependenies are rebuilding from sources)

1. `yarn`
2. `yarn pack:win` or `yarn pack:mac` or `yarn pack:linux`
